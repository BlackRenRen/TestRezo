#pragma once

#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "OnlineSessionSettings.h"
#include "OnlineSubsystemTypes.h"
#include "EOSSessionGameInstance.generated.h"

UCLASS()
class YOURGAME_API UEOSSessionGameInstance : public UGameInstance
{
    GENERATED_BODY()

public:

    /********************************************************************
     * HOST
     ********************************************************************/
     /** Host a new session with enriched metadata */
    UFUNCTION(BlueprintCallable, Category = "Online|EOS")
    bool HostSession(
        const FString& SessionName,
        const FString& MapName,
        const FString& Region,
        const FString& RuleSet,
        bool bIsPrivate,
        int32 TeamAMax,
        int32 TeamBMax
    );

    /** Callback */
    void OnCreateSessionComplete(FName SessionName, bool bWasSuccessful);


    /********************************************************************
     * FIND
     ********************************************************************/
     /** Trigger EOS search request */
    UFUNCTION(BlueprintCallable, Category = "Online|EOS")
    bool FindSessions(int32 MaxResults, bool bWithPresence);

    /** Callback */
    void OnFindSessionsComplete(bool bWasSuccessful);

    /**
     * RAW RESULTS:
     *  - Always kept intact
     *  - Indexes here are the authoritative ones
     */
    TArray<FOnlineSessionSearchResult> SearchResultsCache;


    /********************************************************************
     * CLIENT-SIDE FILTERING (Batch 4)
     ********************************************************************/
     /**
      * Build filtered index set based on client rules;
      * Never reorders SearchResultsCache
      */
    void BuildFilteredIndex(
        const struct FSessionClientFilterParams& FilterParams /** struct defined below */
    );
    /** Filtered indexes referencing SearchResultsCache */
    TArray<int32> FilteredIndexes;


    /********************************************************************
     * RANKING (Batch 5)
     ********************************************************************/
     /**
      * Evaluate score for each FilteredIndex & sort accordingly
      */
    void RankAndSortFiltered(const struct FSessionRankingWeights& Weights);
    /** Post-ranking reordered reference (indexes into SearchResultsCache) */
    TArray<int32> RankedIndexes;


    /********************************************************************
     * JOIN
     ********************************************************************/
     /** Join session by raw index into SearchResultsCache */
    UFUNCTION(BlueprintCallable, Category = "Online|EOS")
    bool JoinSessionByRawIndex(int32 RawIndex);

    /** Join by ranked order (after filtering/ranking) */
    UFUNCTION(BlueprintCallable, Category = "Online|EOS")
    bool JoinSessionByRankIndex(int32 RankIndex);

    void OnJoinSessionComplete(FName SessionName, EOnJoinSessionCompleteResult::Type Result);


    /********************************************************************
     * INTERNAL STATE
     ********************************************************************/
private:
    IOnlineSessionPtr SessionInterface;
    TSharedPtr<FOnlineSessionSearch> SessionSearch;
};
