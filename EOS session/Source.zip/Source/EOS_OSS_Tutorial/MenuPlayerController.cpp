#include "MenuPlayerController.h"

#include "SessionMenuWidget.h"
#include "Blueprint/UserWidget.h"

void AMenuPlayerController::BeginPlay()
{
    Super::BeginPlay();

    UE_LOG(LogTemp, Log, TEXT("AMenuPlayerController::BeginPlay appele"));

    // Tr�s important : ne cr�er le widget que pour le contr�leur local
    if (!IsLocalController())
    {
        UE_LOG(LogTemp, Log, TEXT("AMenuPlayerController: non-local controller, pas de widget de menu"));
        return;
    }

    if (!SessionMenuClass)
    {
        UE_LOG(LogTemp, Error, TEXT("AMenuPlayerController : SessionMenuClass n'est PAS configure !"));
        return;
    }

    SessionMenu = CreateWidget<USessionMenuWidget>(this, SessionMenuClass);
    if (!SessionMenu)
    {
        UE_LOG(LogTemp, Error, TEXT("AMenuPlayerController : CreateWidget a renvoy nullptr !"));
        return;
    }

    // Afficher le menu � l��cran
    SessionMenu->AddToViewport();

    // Mode d�input UI uniquement, focus sur ce widget
    FInputModeUIOnly InputMode;
    InputMode.SetWidgetToFocus(SessionMenu->TakeWidget());
    InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
    SetInputMode(InputMode);

    SetCurrentMenuWidget(SessionMenu);

    bShowMouseCursor = true;
}
