#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "SessionMenuWidget.generated.h"

class USessionRowData;
class UWBP_SessionListItem;

UCLASS()
class EOS_OSS_TUTORIAL_API USessionMenuWidget : public UUserWidget
{
    GENERATED_BODY()

public:
    UPROPERTY(meta = (BindWidget))
    class UPanelWidget* SessionListPanel;

    UPROPERTY(EditAnywhere)
    TSubclassOf<UWBP_SessionListItem> RowClass;

public:
    UFUNCTION(BlueprintCallable)
    void RefreshSessions();

    UFUNCTION(BlueprintCallable)
    void RequestJoin(USessionRowData* Data);

protected:
    virtual void NativeConstruct() override;
};
