// EOSPlayerController.h

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "EOSPlayerController.generated.h"

/**
 * Simple PlayerController for EOS_OSS_Tutorial.
 * Provides a minimal SaveGame function used by EOS_OSS_TutorialCharacter.
 */
UCLASS()
class EOS_OSS_TUTORIAL_API AEOSPlayerController : public APlayerController
{
    GENERATED_BODY()

public:
    AEOSPlayerController();

    /** Save controlled pawn location/rotation to a text file in Saved/. */
    UFUNCTION(BlueprintCallable, Category = "Save")
    void SaveGame();

protected:
    virtual void BeginPlay() override;

private:
    /** Path to the save file (in Saved/) */
    FString SaveFilePath;
};
