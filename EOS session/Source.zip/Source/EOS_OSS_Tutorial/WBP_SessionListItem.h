#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "WBP_SessionListItem.generated.h"

class USessionRowData;

UCLASS()
class EOS_OSS_TUTORIAL_API UWBP_SessionListItem : public UUserWidget
{
    GENERATED_BODY()

public:

    UPROPERTY(BlueprintReadOnly)
    USessionRowData* RowData;

    UFUNCTION(BlueprintCallable)
    void Init(USessionRowData* InData);

    UFUNCTION(BlueprintCallable)
    void OnJoinClicked();
};
