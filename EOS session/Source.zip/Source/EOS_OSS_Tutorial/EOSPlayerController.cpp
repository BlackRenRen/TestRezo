// EOSPlayerController.cpp

#include "EOSPlayerController.h"

#include "GameFramework/Character.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"

AEOSPlayerController::AEOSPlayerController()
{
    // Save in Saved/LastPlayerPosition.txt
    SaveFilePath = FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("LastPlayerPosition.txt"));
}

void AEOSPlayerController::BeginPlay()
{
    Super::BeginPlay();

    UE_LOG(LogTemp, Log, TEXT("AEOSPlayerController::BeginPlay - controller initialized."));
}

void AEOSPlayerController::SaveGame()
{
    ACharacter* MyCharacter = Cast<ACharacter>(GetPawn());
    if (!MyCharacter)
    {
        UE_LOG(LogTemp, Warning, TEXT("SaveGame: no controlled pawn, nothing to save."));
        return;
    }

    const FVector Location = MyCharacter->GetActorLocation();
    const FRotator Rotation = MyCharacter->GetActorRotation();

    const FString SaveString = FString::Printf(
        TEXT("Location: %s\nRotation: %s\n"),
        *Location.ToString(),
        *Rotation.ToString()
    );

    if (FFileHelper::SaveStringToFile(SaveString, *SaveFilePath))
    {
        UE_LOG(LogTemp, Log, TEXT("SaveGame: position saved to %s"), *SaveFilePath);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("SaveGame: failed to save to %s"), *SaveFilePath);
    }
}
