#include "EOSSessionGameInstance.h"
#include "OnlineSubsystem.h"
#include "OnlineSessionSettings.h"
#include "Kismet/GameplayStatics.h"

UEOSSessionGameInstance::UEOSSessionGameInstance()
{
}

void UEOSSessionGameInstance::Init()
{
    Super::Init();

    IOnlineSubsystem* Subsystem = IOnlineSubsystem::Get();
    if (!Subsystem)
    {
        UE_LOG(LogTemp, Error, TEXT("EOSSessionGameInstance::Init : Aucun OnlineSubsystem trouve."));
        return;
    }

    SessionInterface = Subsystem->GetSessionInterface();
    if (!SessionInterface.IsValid())
    {
        UE_LOG(LogTemp, Error, TEXT("SessionInterface invalide."));
        return;
    }

    SessionInterface->OnCreateSessionCompleteDelegates.AddUObject(this, &UEOSSessionGameInstance::OnCreateSessionComplete);
    SessionInterface->OnDestroySessionCompleteDelegates.AddUObject(this, &UEOSSessionGameInstance::OnDestroySessionComplete);
    SessionInterface->OnFindSessionsCompleteDelegates.AddUObject(this, &UEOSSessionGameInstance::OnFindSessionsComplete);
    SessionInterface->OnJoinSessionCompleteDelegates.AddUObject(this, &UEOSSessionGameInstance::OnJoinSessionComplete);

    UE_LOG(LogTemp, Warning, TEXT("UEOSSessionGameInstance initialisee."));
}

void UEOSSessionGameInstance::HostSession(int32 MaxPlayers, bool bIsPrivate)
{
    if (!SessionInterface.IsValid()) return;

    if (SessionInterface->GetNamedSession(NAME_GameSession))
    {
        SessionInterface->DestroySession(NAME_GameSession);
    }

    TSharedPtr<FOnlineSessionSettings> Settings = MakeShareable(new FOnlineSessionSettings());

    Settings->bIsLANMatch = false;
    Settings->bUsesPresence = true;
    Settings->NumPublicConnections = MaxPlayers;
    Settings->NumPrivateConnections = 0;
    Settings->bAllowJoinInProgress = true;
    Settings->bShouldAdvertise = true;

    // ========================
    // Champs AAA
    // ========================
    Settings->Set(FName("SESSION_NAME"), FString("Partie Standard"), EOnlineDataAdvertisementType::ViaOnlineService);
    Settings->Set(FName("MAP_NAME"), FString("GameMap"), EOnlineDataAdvertisementType::ViaOnlineService);
    Settings->Set(FName("REGION"), FString("EU"), EOnlineDataAdvertisementType::ViaOnlineService);
    Settings->Set(FName("RULE_SET"), FString("Default"), EOnlineDataAdvertisementType::ViaOnlineService);

    Settings->Set(FName("IS_PRIVATE"), bIsPrivate, EOnlineDataAdvertisementType::ViaOnlineService);
    Settings->Set(FName("SESSION_AGE_MIN"), 0.f, EOnlineDataAdvertisementType::ViaOnlineService);

    Settings->Set(FName("TEAM_A_CUR"), 0, EOnlineDataAdvertisementType::ViaOnlineService);
    Settings->Set(FName("TEAM_A_MAX"), MaxPlayers / 2, EOnlineDataAdvertisementType::ViaOnlineService);
    Settings->Set(FName("TEAM_B_CUR"), 0, EOnlineDataAdvertisementType::ViaOnlineService);
    Settings->Set(FName("TEAM_B_MAX"), MaxPlayers / 2, EOnlineDataAdvertisementType::ViaOnlineService);

    Settings->Set(FName("TEAM_A_AVG_LEVEL"), 0.f, EOnlineDataAdvertisementType::ViaOnlineService);
    Settings->Set(FName("TEAM_B_AVG_LEVEL"), 0.f, EOnlineDataAdvertisementType::ViaOnlineService);

    TArray<FString> EmptyPlayers;
    Settings->Set(FName("PLAYERS_PRESENT"), EmptyPlayers, EOnlineDataAdvertisementType::ViaOnlineService);

    SessionInterface->CreateSession(0, NAME_GameSession, *Settings);
}

void UEOSSessionGameInstance::FindSessions(int32 MaxResults, bool bIsLAN)
{
    if (!SessionInterface.IsValid())
        return;

    SessionSearch = MakeShareable(new FOnlineSessionSearch());
    SessionSearch->MaxSearchResults = MaxResults;
    SessionSearch->bIsLanQuery = bIsLAN;
    SessionSearch->QuerySettings.Set(SEARCH_PRESENCE, true, EOnlineComparisonOp::Equals);

    SessionInterface->FindSessions(0, SessionSearch.ToSharedRef());
}

void UEOSSessionGameInstance::JoinSessionByIndex(int32 Index)
{
    if (!SessionInterface.IsValid() || !SessionSearch.IsValid()) return;

    if (!SessionSearch->SearchResults.IsValidIndex(Index)) return;

    auto& Result = SessionSearch->SearchResults[Index];

    SessionInterface->JoinSession(0, NAME_GameSession, Result);
}

void UEOSSessionGameInstance::OnCreateSessionComplete(FName Name, bool bWasSuccessful)
{
    if (!bWasSuccessful)
    {
        UE_LOG(LogTemp, Error, TEXT("�chec cr�ation session"));
        return;
    }

    UGameplayStatics::OpenLevel(GetWorld(), "GameMap", true, "listen");
}

void UEOSSessionGameInstance::OnDestroySessionComplete(FName SessionName, bool bWasSuccessful)
{
}

void UEOSSessionGameInstance::OnFindSessionsComplete(bool bWasSuccessful)
{
    LastSessionSearchResults.Empty();

    if (!bWasSuccessful || !SessionSearch.IsValid())
        return;

    LastSessionSearchResults = SessionSearch->SearchResults;

    UE_LOG(LogTemp, Warning, TEXT("Sessions trouv�es : %d"), LastSessionSearchResults.Num());
}

void UEOSSessionGameInstance::OnJoinSessionComplete(FName SessionName, EOnJoinSessionCompleteResult::Type Result)
{
    FString TravelURL;
    if (SessionInterface->GetResolvedConnectString(SessionName, TravelURL))
    {
        APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
        if (PC)
        {
            PC->ClientTravel(TravelURL, ETravelType::TRAVEL_Absolute);
        }
    }
}
