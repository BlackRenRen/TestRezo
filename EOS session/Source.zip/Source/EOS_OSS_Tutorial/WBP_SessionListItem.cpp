#include "WBP_SessionListItem.h"
#include "SessionMenuWidget.h"
#include "SessionRowData.h"

#include "Kismet/GameplayStatics.h"
#include "Blueprint/WidgetBlueprintLibrary.h"


void UWBP_SessionListItem::Init(USessionRowData* InData)
{
    RowData = InData;
}

void UWBP_SessionListItem::OnJoinClicked()
{
    if (!RowData) return;

    // On r�cup�re n'importe quel SessionMenuWidget actif
    TArray<UUserWidget*> Widgets;
    UWidgetBlueprintLibrary::GetAllWidgetsOfClass(GetWorld(), Widgets, USessionMenuWidget::StaticClass(), false);

    if (Widgets.Num() == 0)
        return;

    USessionMenuWidget* Menu = Cast<USessionMenuWidget>(Widgets[0]);
    if (!Menu)
        return;

    Menu->RequestJoin(RowData);
}
