// SessionListItem.h

#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "OnlineSessionSettings.h"
#include "SessionListItem.generated.h"

/**
 * Objet repr�sentant une entr�e de session pour l'UI.
 */
UCLASS()
class EOS_OSS_TUTORIAL_API USessionListItem : public UObject
{
    GENERATED_BODY()

public:
    /** Index dans SessionSearch->SearchResults */
    UPROPERTY(BlueprintReadOnly, Category = "Session")
    int32 SessionIndex;

    /** Nom affich� (host, map, etc.) */
    UPROPERTY(BlueprintReadOnly, Category = "Session")
    FString SessionName;

    /** Nombre de joueurs (current / max) */
    UPROPERTY(BlueprintReadOnly, Category = "Session")
    FString PlayersString;

    /** Ping estim� */
    UPROPERTY(BlueprintReadOnly, Category = "Session")
    int32 PingInMs;
};
