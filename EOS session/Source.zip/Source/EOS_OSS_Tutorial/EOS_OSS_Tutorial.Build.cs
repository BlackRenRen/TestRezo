using UnrealBuildTool;

public class EOS_OSS_Tutorial : ModuleRules
{
    public EOS_OSS_Tutorial(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(
            new string[]
            {
                "Core",
                "CoreUObject",
                "Engine",
                "InputCore",
                "EnhancedInput",
                "UMG",
                "Slate",
                "SlateCore",
                "OnlineSubsystem",
                "OnlineSubsystemUtils"
            }
        );

        PrivateDependencyModuleNames.AddRange(
            new string[]
            {
                "CoreUObject",
                "Engine",
                "Slate",
                "SlateCore",
                "OnlineSubsystem",
                "OnlineSubsystemUtils"
            }
        );

        // IMPORTANT : ces deux modules doivent �tre charg�s dynamiquement
        DynamicallyLoadedModuleNames.AddRange(
            new string[]
            {
                "OnlineSubsystemEOS",
                "OnlineSubsystemEOSPlus"
            }
        );
    }
}
