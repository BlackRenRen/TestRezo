#include "SessionRowData.h"

void USessionRowData::InitFromResult(int32 InIndex, const FOnlineSessionSearchResult& Result)
{
    Index = InIndex;
    RawResult = Result;

    Result.Session.SessionSettings.Get(FName("SESSION_NAME"), SessionName);
    Result.Session.SessionSettings.Get(FName("MAP_NAME"), MapName);
    Result.Session.SessionSettings.Get(FName("REGION"), Region);
    Result.Session.SessionSettings.Get(FName("RULE_SET"), RuleSet);
    Result.Session.SessionSettings.Get(FName("IS_PRIVATE"), bIsPrivate);
    Result.Session.SessionSettings.Get(FName("SESSION_AGE_MIN"), SessionAgeMinutes);

    Result.Session.SessionSettings.Get(FName("TEAM_A_CUR"), TeamA_Current);
    Result.Session.SessionSettings.Get(FName("TEAM_A_MAX"), TeamA_Max);
    Result.Session.SessionSettings.Get(FName("TEAM_B_CUR"), TeamB_Current);
    Result.Session.SessionSettings.Get(FName("TEAM_B_MAX"), TeamB_Max);

    Result.Session.SessionSettings.Get(FName("TEAM_A_AVG_LEVEL"), TeamA_AvgLevel);
    Result.Session.SessionSettings.Get(FName("TEAM_B_AVG_LEVEL"), TeamB_AvgLevel);

    Result.Session.SessionSettings.Get(FName("PLAYERS_PRESENT"), PresentPlayers);

    MaxPlayers = Result.Session.SessionSettings.NumPublicConnections;
    NumConnected = MaxPlayers - Result.Session.NumOpenPublicConnections;
}
