/** Client filtering parameters (Batch 4) */
struct FSessionClientFilterParams
{
    bool bMatchRegionStrict = false;
    FString Region;

    bool bFilterMap = false;
    FString MapName;

    bool bFilterRuleSet = false;
    FString RuleSet;

    bool bRequireFreeSlots = false;
    int32 MinFreeSlotsA = 0;
    int32 MinFreeSlotsB = 0;

    bool bFilterMaxAge = false;
    float MaxAgeMinutes = 30.0f;

    bool bRequireMinPresentPlayers = false;
    int32 MinPresentPlayers = 0;
};


/** Ranking weights (Batch 5) */
struct FSessionRankingWeights
{
    float w_region     = 1.0f;
    float w_map        = 0.5f;
    float w_ruleset    = 0.5f;
    float w_slots      = 1.0f;
    float w_level      = 0.3f;
    float w_friends    = 2.0f;
    float w_age        = 0.7f;
};
