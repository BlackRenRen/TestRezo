﻿#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "OnlineSessionSettings.h"
#include "SessionRowData.generated.h"

UCLASS(BlueprintType)
class YOURGAME_API USessionRowData : public UObject
{
    GENERATED_BODY()

public:

    /** The raw index inside SearchResultsCache (authoritative) */
    UPROPERTY(BlueprintReadOnly, Category = "Online")
    int32 RawIndex;

    /** Pointer-like access to cached result (no deep copy) */
    FOnlineSessionSearchResult* SearchResultPtr;

    /** Simple exposed fields for UI (not authoritative) */
    UPROPERTY(BlueprintReadOnly, Category = "Online")
    FString SessionName;

    UPROPERTY(BlueprintReadOnly, Category = "Online")
    FString MapName;

    UPROPERTY(BlueprintReadOnly, Category = "Online")
    FString Region;

    UPROPERTY(BlueprintReadOnly, Category = "Online")
    FString RuleSet;

    UPROPERTY(BlueprintReadOnly, Category = "Online")
    int32 PresentPlayers = 0;

    UPROPERTY(BlueprintReadOnly, Category = "Online")
    int32 TeamACur = 0;
    UPROPERTY(BlueprintReadOnly, Category = "Online")
    int32 TeamAMax = 0;
    UPROPERTY(BlueprintReadOnly, Category = "Online")
    int32 TeamBCur = 0;
    UPROPERTY(BlueprintReadOnly, Category = "Online")
    int32 TeamBMax = 0;

    UPROPERTY(BlueprintReadOnly, Category = "Online")
    float AgeMinutes = 0.0f;
};
