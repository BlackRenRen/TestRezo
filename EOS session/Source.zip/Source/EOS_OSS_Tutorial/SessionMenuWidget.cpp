#include "SessionMenuWidget.h"
#include "EOSSessionGameInstance.h"
#include "WBP_SessionListItem.h"
#include "SessionRowData.h"
#include "Blueprint/WidgetTree.h"
#include "Components/PanelWidget.h"

void USessionMenuWidget::NativeConstruct()
{
    Super::NativeConstruct();
    RefreshSessions();
}

void USessionMenuWidget::RefreshSessions()
{
    if (!SessionListPanel || !RowClass) return;

    SessionListPanel->ClearChildren();

    UEOSSessionGameInstance* GI = GetWorld()->GetGameInstance<UEOSSessionGameInstance>();
    if (!GI) return;

    const auto& Results = GI->GetLastSearchResults();

    for (int32 i = 0; i < Results.Num(); i++)
    {
        USessionRowData* Data = NewObject<USessionRowData>(this);
        Data->InitFromResult(i, Results[i]);

        UWBP_SessionListItem* Row = CreateWidget<UWBP_SessionListItem>(this, RowClass);
        Row->Init(Data);

        SessionListPanel->AddChild(Row);
    }
}

void USessionMenuWidget::RequestJoin(USessionRowData* Data)
{
    if (!Data) return;

    UEOSSessionGameInstance* GI = GetWorld()->GetGameInstance<UEOSSessionGameInstance>();
    if (!GI) return;

    GI->JoinSessionByIndex(Data->SearchResultIndex);
}
